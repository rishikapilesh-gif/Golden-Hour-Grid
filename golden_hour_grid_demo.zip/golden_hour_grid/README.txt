GOLDEN HOUR GRID — TWO-PAGE CONNECTED SIMULATION

Files:
- ambulance-dispatch.html : enter a fictional accident, patient observations, see route + top 3 hospital candidates, update response status.
- hospital-control.html   : hospital command view, city digital twin, active case, ambulance movement, hospital ranking and preparation timeline.
- start-demo.bat          : starts a local web server and opens both pages in your browser.

HOW TO RUN (recommended):
1. Extract the folder to your computer.
2. Install Python 3 if it is not already installed.
3. Double-click start-demo.bat. It serves the pages at http://localhost:8000 so the two pages can share the same local demo state.
4. Submit a case in Ambulance Dispatch. The Hospital Command page will update automatically. Keep both pages open in the same browser.

Alternative: open either HTML file directly, but browsers may isolate localStorage for file:// pages; the connection is most reliable through start-demo.bat.

IMPORTANT:
- All patient, hospital, traffic, railway, route, ETA and resource data are fictional and simulated.
- No real GPS, live traffic, railway feeds, hospital APIs, cloud database, or clinical decision support is connected.
- Hospital scores are illustrative ranking logic for a hackathon demo, not medical advice or a certified dispatch system.
- Do not enter real patient-identifying data or use this prototype for real emergencies.
