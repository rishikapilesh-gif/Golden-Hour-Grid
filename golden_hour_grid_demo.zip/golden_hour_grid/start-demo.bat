@echo off
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
  echo Python 3 was not found. Install Python 3 or open the HTML files directly.
  pause
  exit /b 1
)
start "Golden Hour Grid server" /min cmd /c "python -m http.server 8000"
timeout /t 2 >nul
start "" http://localhost:8000/ambulance-dispatch.html
start "" http://localhost:8000/hospital-control.html
echo Golden Hour Grid demo is running at http://localhost:8000
 echo Keep this window open while using the simulation.
pause
